<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('papers', function (Blueprint $table) {
            // Change PageFrom and PageTo from integer to string for storing links/text
            $table->string('PageFrom', 255)->nullable()->change();
            $table->string('PageTo', 255)->nullable()->change();
        });
    }

    public function down(): void
    {
        Schema::table('papers', function (Blueprint $table) {
            $table->integer('PageFrom')->nullable()->change();
            $table->integer('PageTo')->nullable()->change();
        });
    }
};
