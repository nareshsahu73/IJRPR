<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('papers', function (Blueprint $table) {
            // Check and add columns only if they don't exist
            if (!Schema::hasColumn('papers', 'paper_status')) {
                $table->string('paper_status', 50)->nullable();
            }
            if (!Schema::hasColumn('papers', 'final_manuscript')) {
                $table->string('final_manuscript', 50)->nullable();
            }
            if (!Schema::hasColumn('papers', 'copy_right_received')) {
                $table->string('copy_right_received', 10)->nullable();
            }
            if (!Schema::hasColumn('papers', 'filled_copy_right')) {
                $table->string('filled_copy_right', 255)->nullable();
            }
            if (!Schema::hasColumn('papers', 'status_of_payment')) {
                $table->string('status_of_payment', 50)->nullable();
            }
            if (!Schema::hasColumn('papers', 'invoice_no')) {
                $table->string('invoice_no', 100)->nullable();
            }
            if (!Schema::hasColumn('papers', 'certificate_link')) {
                $table->string('certificate_link', 255)->nullable();
            }
            if (!Schema::hasColumn('papers', 'formatted_doc')) {
                $table->string('formatted_doc', 255)->nullable();
            }
            if (!Schema::hasColumn('papers', 'plagiarism_report')) {
                $table->string('plagiarism_report', 255)->nullable();
            }
            if (!Schema::hasColumn('papers', 'plagiarism_percentage')) {
                $table->string('plagiarism_percentage', 255)->nullable();
            }
            if (!Schema::hasColumn('papers', 'email_template_id')) {
                $table->integer('email_template_id')->nullable();
            }
            if (!Schema::hasColumn('papers', 'updated_at')) {
                $table->timestamp('updated_at')->nullable();
            }
        });
    }

    public function down(): void
    {
        Schema::table('papers', function (Blueprint $table) {
            $columns = [
                'paper_status',
                'final_manuscript',
                'copy_right_received',
                'filled_copy_right',
                'status_of_payment',
                'invoice_no',
                'certificate_link',
                'formatted_doc',
                'plagiarism_report',
                'plagiarism_percentage',
                'email_template_id',
                'updated_at',
            ];

            foreach ($columns as $column) {
                if (Schema::hasColumn('papers', $column)) {
                    $table->dropColumn($column);
                }
            }
        });
    }
};
